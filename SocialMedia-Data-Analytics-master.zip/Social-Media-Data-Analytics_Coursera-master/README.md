# Social Media Data Analytics

**MOOC Platform**: Coursera

**Offering University**: Rutgers the State University of New Jersey

**Course title**: Social Media Data Analytics

**Description**: This repo contains all the assignments and exercies which were part of this course.

**Course link**:  [Social Media Data Analytics](https://www.coursera.org/learn/social-media-data-analytics)

**Course Certificate**: https://www.coursera.org/account/accomplishments/certificate/9HDENBCTMZ99
